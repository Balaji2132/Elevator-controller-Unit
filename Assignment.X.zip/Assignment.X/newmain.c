/*
 * File:   newmain.c
 * Author: barat
 *
 * Created on 14 March, 2024, 6:06 PM
 */



#include<xc.h>
#include<stdio.h>

//#pragma config FOSC = HS //Oscillator Selection bits (HS Oscillator)
//#pragma config PWRTE = ON //Power-up Timer Enable bit (PWRT enabled)
#pragma config BOREN = ON //brown-out reset enable bit (BOR enabled)
#pragma config LVP = OFF //Low-volatge (Single-supply) in circuit serialprogramming enable bit
#pragma config CPD = OFF //Data EEPROM Memory code protection bit 
//#pragma config WRT = OFF // Flash Program Memory Write Enable bits (Write protection off; all program memory written to by EECON control)
//#pragma config CP = OFF // Flash Program Memory Code Protection bit (Code protection off)
#pragma config WDT = OFF // Watchdog timer enable bit
#define _XTAL_FREQ 20000000

#define WINCH_SPEED_PIN RC0  //PWM speed control pin
#define WINCH_DIRECTION_PIN LATCbits.LATC1 //Direction control pin
#define DOOR_RELAY_PIN PORTBbits.RB0 //Door relay control pin
#define ELEVATOR_POSITION_PIN AN0 //Elevator position sensor pin

#define FIRST_FLOOR_HEIGHT 0.0
#define SECOND_FLOOR_HEIGHT 2.8
#define THIRD_FLOOR_HEIGHT 5.6

#define LCD_DATA PORTD  //LCD data pins
#define LCD_EN PORTEbits.RE1 //LCD Enable pin
#define LCD_RS PORTEbits.RE2 //LCD Register Select pin


//Function Prototypes
void initialiseIO(void);
void initialisePWM(void);
void initialiseDisplay(void);
void initialiseADC(void);
unsigned int measureElevatorPosition(void);
unsigned int determineCurrentFloor(unsigned int position);
unsigned char testCallButtonInputs(void);
unsigned char testFloorSelectButtons(void);
unsigned char testDoorSensor(void);
void openDoor(void);
void closeDoor(void);
void controlWinch(unsigned char speedPercent, unsigned char direction);
void writeToDisplay(unsigned int position, unsigned int currentFloor);

void main(void)
{
    initialiseIO();
    initialisePWM();
    initialiseDisplay();
    initialiseADC();

    unsigned char prevButtonStatus = 0; // Variable to store previous button status
    unsigned char currentButtonStatus; // Variable to store current button status
    unsigned int currentPosition = 0; // Current position of the elevator
    unsigned char winchSpeed = 0; // Initial winch speed
    unsigned char movingInside = 0; // Flag to indicate movement based on inside button press

    while (1)
    {
        unsigned int position = measureElevatorPosition();
        unsigned int currentFloor = determineCurrentFloor(position);

        // Get the current button status
        currentButtonStatus = testCallButtonInputs();

        // Check if any new button is pressed from outside
        if (currentButtonStatus != prevButtonStatus)
        {
            if (currentButtonStatus & 0b00000001) // Button A pressed (First Floor)
            {
                controlWinch(0, 1); // Go up
                movingInside = 0; // Reset flag
            }
            else if (currentButtonStatus & 0b00000010) // Button B pressed (Second Floor)
            {
                controlWinch(0, 0); // Go down
                movingInside = 0; // Reset flag
            }
            else if (currentButtonStatus & 0b00000100) // Button C pressed (Second Floor)
            {
                controlWinch(0, 1); // Go up
                movingInside = 0; // Reset flag
            }
            else if (currentButtonStatus & 0b00001000) // Button D pressed (Third Floor)
            {
                controlWinch(0, 0); // Go down
                movingInside = 0; // Reset flag
            }

            prevButtonStatus = currentButtonStatus; // Update previous button status
        }

        // Check if any button is pressed from inside the elevator
        currentButtonStatus = testFloorSelectButtons();
        if (currentButtonStatus != 0)
        {
            if (currentButtonStatus & 0b00000001) // Button E pressed (First Floor inside)
            {
                if (currentFloor == 1) // If already on first floor, open the door
                {
                    openDoor();
                    __delay_ms(2000); // Wait for 2 seconds
                    closeDoor();
                }
                else if (currentFloor < 1) // Go up if below first floor
                {
                    controlWinch(0, 1); // Go up
                    movingInside = 1; // Set flag for movement based on inside button press
                }
                else if (currentFloor > 1) // Go down if above first floor
                {
                    controlWinch(0, 0); // Go down
                    movingInside = 1; // Set flag for movement based on inside button press
                }
            }
            else if (currentButtonStatus & 0b00000010) // Button F pressed (Second Floor inside)
            {
                if (currentFloor == 2) // If already on second floor, open the door
                {
                    openDoor();
                    __delay_ms(2000); // Wait for 2 seconds
                    closeDoor();
                }
                else if (currentFloor < 2) // Go up if below second floor
                {
                    controlWinch(0, 1); // Go up
                    movingInside = 1; // Set flag for movement based on inside button press
                }
                else if (currentFloor > 2) // Go down if above second floor
                {
                    controlWinch(0, 0); // Go down
                    movingInside = 1; // Set flag for movement based on inside button press
                }
            }
            else if (currentButtonStatus & 0b00000100) // Button G pressed (Third Floor inside)
            {
                if (currentFloor == 3) // If already on third floor, open the door
                {
                    openDoor();
                    __delay_ms(2000); // Wait for 2 seconds
                    closeDoor();
                }
                else if (currentFloor < 3) // Go up if below third floor
                {
                    controlWinch(0, 1); // Go up
                    movingInside = 1; // Set flag for movement based on inside button press
                }
                else if (currentFloor > 3) // Go down if above third floor
                {
                    controlWinch(0, 0); // Go down
                    movingInside = 1; // Set flag for movement based on inside button press
                }
            }
        }

        // Handle automatic movement based on inside button press
        if (movingInside)
        {
            if (currentFloor == 1 && currentPosition == FIRST_FLOOR_HEIGHT * 1000)
            {
                openDoor();
                __delay_ms(2000); // Wait for 2 seconds
                closeDoor();
                movingInside = 0; // Reset flag after reaching desired floor
            }
            else if (currentFloor == 2 && currentPosition == SECOND_FLOOR_HEIGHT * 1000)
            {
                openDoor();
                __delay_ms(2000); // Wait for 2 seconds
                closeDoor();
                movingInside = 0; // Reset flag after reaching desired floor
            }
            else if (currentFloor == 3 && currentPosition == THIRD_FLOOR_HEIGHT * 1000)
            {
                openDoor();
                __delay_ms(2000); // Wait for 2 seconds
                closeDoor();
                movingInside = 0; // Reset flag after reaching desired floor
            }
        }

        currentPosition = position; // Update current position

        // Handle winch speed increment
        if (winchSpeed < 100)
        {
            winchSpeed += 10;
            controlWinch(winchSpeed, WINCH_DIRECTION_PIN); // Maintain the current direction
        }

        // Handle other elevator operations like opening/closing door, updating display, etc.
        unsigned char doorStatus = testDoorSensor();

        if (doorStatus == 0)
        {
            openDoor();
        }
        else
        {
            closeDoor();
        }

        writeToDisplay(position, currentFloor);
    }
}

void initialiseIO(void)
{
    TRISCbits.TRISC0 = 0; //Direction control pin as output
    TRISCbits.TRISC1 = 0; //Door relay control pin as output
    TRISBbits.TRISB0 = 0; //Direction control pin as output
    ADCON1bits.PCFG0 = 0; // Configure AN0 as analog input for elevator position sensor

    TRISBbits.TRISB1 = 1; //Button A
    TRISBbits.TRISB2 = 1; //Button B
    TRISBbits.TRISB3 = 1; //Button C
    TRISBbits.TRISB4 = 1; //Button D
    TRISBbits.TRISB5 = 1; //Button E
    TRISBbits.TRISB6 = 1; //Button F
    TRISBbits.TRISB7 = 1; //Button G
    TRISAbits.TRISA0 = 1; //Button H (Door sensor)

    TRISD = 0; //Data lines as output
    TRISEbits.TRISE1 = 0; //EN pin as output
    TRISEbits.TRISE2 = 0; //RS pin as output

}

void initialisePWM(void)
{
    TRISC1 = 0; // Make CCP2 pin as output for PWM
    CCP2CON = 0; // Initialize CCP2 module
    PR2 = 255; //Set PWm period (0xFF)
    T2CON = 0b00000100; // Timer2 ON, Prescaler 1:1
}

void initialiseDisplay(void)
{
    __delay_ms(15); //LCD Power on with delay
    LCD_RS = 0; //Disable LCD
    LCD_EN = 0; // Command mode, select instruction register
    __delay_ms(5); //Delay for LCD to Powerup
    LCD_DATA = 0x38; //2 lines, 5x7 matrix
    LCD_EN = 1;
    __delay_ms(5); //Delay
    LCD_EN = 0;
    __delay_ms(1);
    LCD_DATA = 0x0E; //Display on, curson blinking
    LCD_EN = 1;
    __delay_ms(1);
    LCD_EN = 0;
    __delay_ms(1);
    LCD_DATA = 0x01; //Clear Display
    LCD_EN = 1;
    __delay_ms(1);
    LCD_EN = 0;
    __delay_ms(1);
    LCD_DATA = 0x06; //Increment cursor
    LCD_EN = 1;
    __delay_ms(1);
    LCD_EN = 0; //Disable LCD

}

void initialiseADC(void)
{
    ADCON0 = 0b00000001; //Select AN0 as analog input
    ADCON1 = 0b00000000;  //Vref+= VDD, Vref -= VSS
    ADCON2 = 0b10001110; //Right justify result, Fosc/64, acquisition time 4TAD
}

unsigned int measureElevatorPosition(void)
{
    GO_nDONE = 1; //Start ADC conversion
    while(GO_nDONE);//Wait until the conversion is complete
    return ((unsigned int)ADRESH << 8) + ADRESL; //Return ADC result
}

unsigned int determineCurrentFloor(unsigned int position)
{
    if (position >= (FIRST_FLOOR_HEIGHT * 1000 - 20) && position <= (FIRST_FLOOR_HEIGHT * 1000 + 20))
        return 1;
    else if (position >= (SECOND_FLOOR_HEIGHT * 1000 - 20) && position <=(SECOND_FLOOR_HEIGHT * 1000 + 20))
        return 2;
    else if (position >= (THIRD_FLOOR_HEIGHT * 1000 - 20) && position <= (THIRD_FLOOR_HEIGHT * 1000 + 20))
        return 3;
    else
        return 0;// Between Floors
}

unsigned char testCallButtonInputs(void)
{
    unsigned char buttonStatus = 0;
    if (PORTBbits.RB0 == 0)
    {
        __delay_ms(15);
        if (PORTBbits.RB0 == 0)
        {
            buttonStatus |= 0b00000001; //Button A pressed
        }
    }

    if (PORTBbits.RB1 == 0)
    {
        __delay_ms(15);
        if (PORTBbits.RB1 == 0)
        {
            buttonStatus |= 0b00000010; //Button B pressed
        }
    }

    if (PORTBbits.RB2 == 0)
    {
        __delay_ms(15);
        if (PORTBbits.RB2 == 0)
        {
            buttonStatus |= 0b00000100; //Button C pressed
        }
    }
    
    if (PORTBbits.RB3 == 0)
    {
        __delay_ms(15);
        if (PORTBbits.RB3 == 0)
        {
            buttonStatus |= 0b00001000; //Button D pressed
        }
    }

    return buttonStatus;
}

unsigned char testFloorSelectButtons(void)
{
    unsigned char buttonStatus = 0;

    if (PORTBbits.RB4 == 0)
    {
        __delay_ms(15);
        if (PORTBbits.RB4 == 0)
        {
            buttonStatus |= 0b00000001; //Button E pressed
        }
    }

    if (PORTBbits.RB5 == 0)
    {
        __delay_ms(15);
        if (PORTBbits.RB5 == 0)
        {
            buttonStatus |= 0b00000010; //Button F pressed
        }
    }

    if (PORTBbits.RB6 == 0)
    {
        __delay_ms(15);
        if (PORTBbits.RB6 == 0)
        {
            buttonStatus |= 0b00000100; //Button G pressed
        }
    }

    return buttonStatus;
}

unsigned char testDoorSensor(void)
{
    __delay_ms(15);
    return PORTAbits.RA0;
}

void openDoor(void)
{
    DOOR_RELAY_PIN = 1; //Activate relay

}

void closeDoor(void)
{
    DOOR_RELAY_PIN = 0; //Deactivate relay
}

void controlWinch(unsigned char speedPercent, unsigned char direction)
{
    unsigned int pwmValue = (speedPercent * 10) * 1023 / 100; // Convert speed percentage to PWM value (0-1023)

    WINCH_DIRECTION_PIN = direction;

    CCP2CON = 0b00001100; // PWM mode, LSBs from CCPR2L and MSBs from DC2B1:DC2B0
    CCPR2L = (unsigned char)(pwmValue >> 2); // Load PWM duty cycle
    DC2B0 = pwmValue & 0b00000001; // Load LSBs of PWM duty cycle
    DC2B1 = (pwmValue & 0b00000010) >> 1; // Load MSBs of PWM duty cycle
}

void writeToDisplay(unsigned int position, unsigned int currentFloor)
{
    char displayData[16]; //Maximum 16 charachters for LCD display

    LCD_RS = 0; 
    LCD_DATA = 0x01;
    LCD_EN = 1; 
    __delay_ms(1);
    LCD_EN = 0;
    __delay_ms(2);

    if(currentFloor != 0)
    {
        sprintf(displayData, "Floor: %d", currentFloor);
    }
    else
    {
        sprintf(displayData, "Floor: -");
    }

    LCD_RS = 0;
    LCD_DATA = 0x80; //Set DDRAM address to start of second
    LCD_EN = 1;
    __delay_ms(1);
    LCD_EN = 0;
    __delay_ms(1);

    LCD_RS = 1; //select data register
    for  (int i=0; displayData[i] != '\0'; ++i)
    {
        LCD_DATA = displayData[i]; //Write character
        LCD_EN = 1;
        __delay_ms(1);
        LCD_EN = 0;
        __delay_ms(1);
    }

    sprintf(displayData, "Pos: %d mm", position);

    LCD_RS = 0; //select instruction register
    LCD_DATA = 0xC0; //Set DDRAM address to 0x40
    LCD_EN = 1;
    __delay_ms(1);
    LCD_EN = 0;
    __delay_ms(1);

    LCD_RS = 1;
    for(int i=0; displayData[i] != '\0'; i++)
    {
        LCD_DATA = displayData[i];
        LCD_EN = 1;
        __delay_ms(1);
        LCD_EN = 0;
        __delay_ms(1);
    }

}